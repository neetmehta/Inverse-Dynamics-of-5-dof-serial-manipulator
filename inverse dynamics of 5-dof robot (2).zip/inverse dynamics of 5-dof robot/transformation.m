function A = transformation(theta, alpha, link_length, joint_offset)
A = vpa([cos(theta), -sin(theta)*round(cos(alpha),3), sin(theta)*round(sin(alpha),3), link_length*cos(theta);
         sin(theta), cos(theta)*round(cos(alpha),3), -cos(theta)*round(sin(alpha),3), link_length*sin(theta);
         0,         round(sin(alpha),3),             round(cos(alpha),3)             joint_offset;
         0,         0,                      0,                     1                     ],4);
end