function A=torque(i,D,theta_double_dot,h,theta_dot,C)
A=[inertia_term(i,D,theta_double_dot)+coriolis_term(i,h,theta_dot)+gravity_term(i,C)];
end
