function A=Dmatrix(i,c,J,U)
a=max(i,c);
A=[0];
for j=a:5
    A=A+trace(U{j,c}*J{j}*(U{j,i}).');
end
end