function A = gravity_term(i,C)
A=C{i};
end