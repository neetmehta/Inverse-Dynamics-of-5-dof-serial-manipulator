%% 1.) inverse dynamics
%% 1.) defining parameters
clear
clc
syms('theta%d(t)',[1 5]);
syms('theta_dot%d(t)',[1 5]);
syms('theta_double_dot%d(t)',[1 5]);
syms('T_0_%d',[1 5]);
a =     [0.055 0.24 0.22 0 0];
d =     [0.107 0 0 0 0.16];
alpha = [-pi/2 0 0 -pi/2 0];
theta=[theta1(t) theta2(t) theta3(t) theta4(t) theta5(t)];
theta_dot=[theta_dot1(t) theta_dot2(t) theta_dot3(t) theta_dot4(t) theta_dot5(t)];
theta_double_dot=[theta_double_dot1(t) theta_double_dot2(t) theta_double_dot3(t) theta_double_dot4(t) theta_double_dot5(t)];

%% 2.) deriving transformation matricies
trans_mat(:,:,1)=transformation(theta(1),alpha(1),a(1),d(1));
trans_mat(:,:,2)=transformation(theta(2),alpha(2),a(2),d(2));
trans_mat(:,:,3)=transformation(theta(3),alpha(3),a(3),d(3));
trans_mat(:,:,4)=transformation(theta(4),alpha(4),a(4),d(4));
trans_mat(:,:,5)=transformation(theta(5),alpha(5),a(5),d(5));
