function A=Umatrix(i,j,transmat)
syms('theta%d',[1 5]);
theta=[theta1 theta2 theta3 theta4 theta5];
A=diff(transmat{i},theta(j));
end