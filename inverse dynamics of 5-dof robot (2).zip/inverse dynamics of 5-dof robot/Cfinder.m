function A = Cfinder(i,g,m,r,U)
A=[0];
for j=i:5
    A=A+(-m(j)*g*U{j,i}*r{j});
end
end