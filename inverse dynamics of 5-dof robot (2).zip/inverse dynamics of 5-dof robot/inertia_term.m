function A = inertia_term(i,D,theta_double_dot)
A=[0];
for c=1:5
    A=A+D{i,c}*theta_double_dot(c);
end
end