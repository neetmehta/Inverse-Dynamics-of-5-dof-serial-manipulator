function A=coriolis_term(i,h,theta_dot)
A=[0];
for c=1:5
    for d=1:5
        A = A + h{i,c,d}*theta_dot(c)*theta_dot(d);
    end
end
end