%%inverse dynamics
clear
clc 
close all

%%%% Kinematics %%%%
%% 1.) defining parameters
digits(4);
a =     [0.055 0.24 0.22 0 0];                                                                                          % Link Length
d =     [0.107 0 0 0 0.16];                                                                                             % Joint Offset
alpha = [-pi/2 0 0 -pi/2 0];                                                                                            % Angle of offset
theta=[theta1 theta2 theta3 theta4 theta5];                                                                             % Symbolic Variable theta 
theta_dot=[theta_dot1 theta_dot2 theta_dot3 theta_dot4 theta_dot5];                                                     % Symbolic Variable theta_dot
theta_double_dot=[theta_double_dot1 theta_double_dot2 theta_double_dot3 theta_double_dot4 theta_double_dot5];           % Symbolic Variable theta_double_dot

%% 2.) deriving transformation matricies
% Evaluate each transformation matrix from (i-1)th joint to ith joint 
T_0_1=vpa(transformation(theta1,alpha(1),a(1),d(1)),3);
T_1_2=vpa(transformation(theta2,alpha(2),a(2),d(2)),3);
T_2_3=vpa(transformation(theta3,alpha(3),a(3),d(3)),3);
T_3_4=vpa(transformation(theta4,alpha(4),a(4),d(4)),3);
T_4_5=vpa(transformation(theta5,alpha(5),a(5),d(5)),3);

%% Transformation matrix with respect to base
% Evaluate transformation matrix of all joints w.r.t base
trans_mat=cell(1,5);
trans_mat{1}=simplify(T_0_1);
trans_mat{2}=simplify(T_0_1*T_1_2);
trans_mat{3}=simplify(T_0_1*T_1_2*T_2_3);
trans_mat{4}=simplify(T_0_1*T_1_2*T_2_3*T_3_4);
trans_mat{5}=simplify(T_0_1*T_1_2*T_2_3*T_3_4*T_4_5);

%%%% Dynamics %%%%
%% U finding
% Find U matrix
U=cell(5);
for i=1:5
    for j=1:5
        if i>=j
            U{i,j}=simplify(Umatrix(i,j,trans_mat));
        end
    end
end

%% Inertia Tensor
% enter mass and inertial properties
J=cell(1,5);
J{1}=tensorfinder(0.00120955,0.00892709,0.00884996,0.00077022,0,0.00032045,0.0071435,0.00770134,0.00448443,2.1212721);
J{2}=tensorfinder(0.00120955,0.00892709,0.00884996,0,0,-0.0006238,-0.15179301,-0.00016284,0.00282876,1.23151641);
J{3}=tensorfinder(0.00032097,0.0029448,0.00295378,0,0,-0.00015335,-0.11641024,0,0.02195905,0.45798449);
J{4}=tensorfinder(0.00026269,0.00019062,0.00015014,0.00077022,0,0,0.00066442,-0.01856505,0.0387213,0.23);
J{5}=tensorfinder(0.00037628,0.00033889,0.00015436,0,0,0,0,0.00085401,-0.01419794,0.481);

%% D finding
% finding D matrix for inertia terms
D = cell(5);
for i=1:5
    for c=1:5
        D{i,c}=simplify(Dmatrix(i,c,J,U));
    end
end

%% h finding
% Finding h for coriolis terms
%% defining Uijk matrix
U_2=cell(5,5,5);
U_2{1,1,5}=T_0_1;
for i=1:5
    for j=1:5
        for k=1:5
            U_2{k,j,i}=diff(U{k,j},theta(i));
        end
    end
end

h=cell(5,5,5);
for i=1:5
    for j=1:5
        for k=1:5
            h{i,j,k}=hfinder(i,j,k,U_2,J,U);
        end
    end
end

%% finding C
% Find C for gravity terms
%% defining gravity parameters
g=[0 0 -9.81 0];
m=[2.1212721, 1.23151641, 0.45798449, 0.23, 0.481];
r=cell(1,5);
r{1}=[0.0071435,0.00770134,0.00448443, 1].';
r{2}=[-0.15179301,-0.00016284,0.00282876, 1].';
r{3}=[-0.11641024,0,0.02195905, 1].';
r{4}=[0.00066442,-0.01856505,0.0387213, 1].';
r{5}=[0,0.00085401,-0.01419794, 1].';

%% finding C
C=cell(1,5);
for i=1:5
    C{i}=Cfinder(i,g,m,r,U);
end

%% finding torque
% Find torque using Lagrange-euler formulation
joint_torque=cell(1,5);
for i=1:5
    joint_torque{i}=vpa(simplify(torque(i,D,theta_double_dot,h,theta_dot,C),4));
end


%% Substution of Joint angle, Joint velocity, Joint accleration
time=1:0.01:3;
jt=cell(1,5);
for i=1:5
    jt{i}=matlabFunction(joint_torque{i});
end

%% Joint Torque value
fos = 3;
for i=1:4
    
    N{i}=fos*(jt{i}((120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180));
    
end

N{5}=fos*(jt{5}((120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(120*time.^2-(80/3)*time.^3)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240*time-80*time.^2)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180,(240-160*time)*pi/180));
%     plot(time,M)

%% Graph Plot
% plotting the graph of each joint torque


for j=1:5
    subplot(3,2,j)
    str_e = sprintf('Joint torque(%d) [N.m]',[j]);
    str_f = sprintf('Joint Torque %d vs. Time',[j]);
    ylabel(str_e);
    xlabel('Time [t]');
    title(str_f);
end

    