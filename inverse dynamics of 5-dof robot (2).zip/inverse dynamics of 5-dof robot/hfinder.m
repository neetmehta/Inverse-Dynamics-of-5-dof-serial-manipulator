function A=hfinder(i,c,d,U_2,J,U)
a=max([i c d]);
A=[0];
for j=a:5
    A = A + trace(U_2{j,c,d}*J{j}*(U{j,i}).');
end
end