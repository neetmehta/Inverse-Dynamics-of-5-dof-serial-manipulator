function A=tensorfinder(Ixx,Iyy,Izz,Ixy,Iyz,Izx,x,y,z,m)
A=[(-Ixx+Iyy+Izz)/2, Ixy,             Izx,            m*x;
    Ixy,            (Ixx-Iyy+Izz)/2,  Iyz,            m*y;
    Izx,             Iyz,            (Ixx+Iyy-Izz)/2, m*z;
    m*x,             m*y,             m*z,            m  ];
end